/* 20. Looping Programs
1) Write a program to print the 1 to 10 using For loop. */

void main() {
  var i;

  for (i = 1; i <= 10; i++) print("$i");
}
