/*20. Looping Programs
2). Write a Program to print the 51 to 60 using while loop*/

void main() {
  var i;

  i = 51;
  while (i <= 60) {
    print("$i");
    i++;
  }
}
