//48.Create a program using Map
void main() {
  Map name = {"Key": "Value", "name": "Ritesh", "Age": "20"};

  print(name["Key"]);
}
