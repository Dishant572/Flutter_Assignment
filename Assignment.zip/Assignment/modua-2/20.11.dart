/* 
20.11

*
**
***
****
*****

*/

import 'dart:io';

void main(){
    var r,c;

    for(r=1;r<=5;r++){
        for(c=1;c<=r;c++){
           stdout.write("*");
        }
        print("");
    }

}