import 'package:flutter/material.dart';
import 'package:CRUD/Student_Details.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: StudentDetails(),
  ));
}
